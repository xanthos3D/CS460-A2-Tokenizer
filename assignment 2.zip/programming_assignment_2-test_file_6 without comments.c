                                                      
                                                      
                                                      
procedure main (void)
{
  int counter;

  counter = 1f;
  printf ("counter = %d\n, counter);
}

