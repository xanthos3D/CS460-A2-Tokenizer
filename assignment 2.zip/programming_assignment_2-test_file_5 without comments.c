                                                      
                                                      
                                                      
procedure main (void)
{
  int counter;

  1counter = 2;
  printf ("counter = %d\n", 1counter);
}

